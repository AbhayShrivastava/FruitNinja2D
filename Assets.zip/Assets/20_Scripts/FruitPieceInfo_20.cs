﻿using UnityEngine;
using System.Collections;

public class FruitPieceInfo_20 : MonoBehaviour {

	public string collisionTag = "TAG_1";

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.gameObject.CompareTag(collisionTag))
			gameObject.SetActive(false);
	}
}
