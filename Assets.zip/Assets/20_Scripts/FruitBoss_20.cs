﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitBoss_20 : MonoBehaviour {

	private Rigidbody2D rb;

	void Start()
	{
		rb = GetComponent<Rigidbody2D> ();
        StartCoroutine(DeadForTime());
    }

	void Update () {

		if(transform.position.y > -3)
		{
			rb.gravityScale -= Time.deltaTime;
			rb.drag += Time.deltaTime;
			rb.angularDrag += Time.deltaTime;
			if(rb.gravityScale <= 0)
			{
				rb.gravityScale = 0;
				rb.drag = 5;

			}

			GameManager_20.instance.effectCamera = true;
		}
		
	}

	IEnumerator DeadForTime()
	{
		yield return new WaitForSeconds (4);
		GetComponent<FruitInformation_20> ().TakeDamage();
     
        StartCoroutine(DeadForTime());
	}
}
