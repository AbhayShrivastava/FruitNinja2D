﻿using UnityEngine;
using System.Collections;

public class AudioMaster_20 : MonoBehaviour {

	public static AudioMaster_20 Instance{ get; set;}

	[SerializeField]  AudioSource music;
	[SerializeField]  public AudioSource audioCut;
    


	public float timeToPlay = 0.1f;
	private float timeleft;

   
	void Awake()
	{
        if (Instance == null)
            Instance = this;

        else if (Instance != this)
            Destroy(gameObject);


	}

    private void Update()
    {
        if (GameManager_20.instance.gameOver==true)
        {
            music.playOnAwake = false;
            music.loop = false;
            music.clip = GameManager_20.instance.SFXclips[2];
            if (!music.isPlaying)
            {
                music.PlayDelayed(1);
                
            }
        }
    }

    public void ApplyAudioCutWheneStop()
	{
		if (!audioCut.isPlaying)
			audioCut.Play ();
	}

	public void ApplyAudioCut()
	{


		StopCoroutine (Play ());
		StartCoroutine (Play ());
			
	}

	IEnumerator Play()
	{
		timeleft = timeToPlay;
		while(timeleft > 0)
		{
			timeleft -= Time.deltaTime;

			yield return null;
		}
		audioCut.Play ();
		
	}
}
