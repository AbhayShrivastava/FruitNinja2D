﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitInformation_20 : MonoBehaviour {

	public Sprite[] spriteCut;
	private Transform[] picecs;

	public GameObject cut;
	public int maxCuts;
	public int maxHealth = 1;
	public float speedCut = 5;
	public float distanceCutY = 0.3f;
	public float distanceCutX = 0.3f;
	public Transform parentRot;
	public float deltaRotate = 1;
	public Color colorFruit;

	public ParticleSystem psEffect;
	public GameObject splashFruit;

	private int health;
	private bool isDead = false;
	private int originalHealth;

	private GameObject rightPiece;
	private GameObject leftPiece;

	public bool isBoss = false;

	void Start()
	{
		isDead = false;
		picecs = new Transform[spriteCut.Length];
		for (int i = 0; i < spriteCut.Length; i++) {

			GameObject newPiece = Instantiate(cut, transform.position, parentRot.localRotation) as GameObject;
			picecs[i] = newPiece.transform;
			newPiece.SetActive(false);
		}
	}

	void OnEnable()
	{
		isDead = false;
		health = maxHealth;
	}

	void Update () {

		Vector2 mousePos = MouseController_20.Instance.GetMousePosition();

		if(CanCut())
		{
			CutLookAt(parentRot.gameObject, mousePos, deltaRotate);
		}
		if(health <= 0)
		{
			isDead = true;
		}

		if(isDead)
		{
			if(maxCuts > 0)
			{

				float randomRotate = Random.Range (-70, 70);

				int flip = 1;

				for (int i = 0; i < picecs.Length; i++) {
					
					flip *= -1;

					GameObject newPiece = picecs[i].gameObject;
					newPiece.SetActive(true);

					newPiece.transform.position = transform.position;
					newPiece.transform.rotation = parentRot.localRotation;
					

					if(distanceCutY > 0)
						newPiece.transform.position = newPiece.transform.position - newPiece.transform.up * distanceCutY * flip; 
					if(distanceCutX > 0)
						newPiece.transform.position = newPiece.transform.position + newPiece.transform.right * distanceCutX * flip; 


					newPiece.transform.localScale = transform.localScale;

					if(!newPiece.AddComponent<CircleCollider2D>())
						newPiece.AddComponent<CircleCollider2D>().radius = 3;

					if(!newPiece.AddComponent<FruitPieceInfo_20>())
						newPiece.AddComponent<FruitPieceInfo_20>();

					newPiece.GetComponent<SpriteRenderer>().sprite = spriteCut[i];
					newPiece.GetComponent<Rigidbody2D>().AddTorque(randomRotate);
					newPiece.GetComponent<Rigidbody2D>().velocity = newPiece.transform.up * speedCut * -flip;
				}
			}

		if(isBoss)
            {
                FindObjectOfType<FruitManager_20>().isShootBoss = false;
                GameManager_20.instance.effectCamera = false;
                GameManager_20.instance.BossHits = 0;
                GameManager_20.instance.HitText.gameObject.SetActive(false);
                Camera.main.transform.position = new Vector3(0, 0, -10);

            }


            GameManager_20.instance.NoOfCuts++;
			gameObject.SetActive(false);
			return;
		}
	}

	bool CanCut()
	{
		Vector2 mousePos = Camera.main.ScreenToWorldPoint (Input.mousePosition);
		return Vector2.Distance (transform.position, mousePos) > 0.2f;
	}

	public void GetEffect()
	{
		Instantiate(psEffect.gameObject, transform.position, Quaternion.identity);
		GameObject newSplash = Instantiate (splashFruit, transform.position + transform.forward * 1, transform.rotation) as GameObject;
		newSplash.GetComponent<SpriteRenderer> ().color = colorFruit;
	}

	void CutLookAt(GameObject a, Vector3 pos, float delta = 1)
	{
		float deltaX = (a.transform.position.x - pos.x) - 0.1f;
		float deltaY = (a.transform.position.y - pos.y) - 0.1f;
		float angle = Mathf.Atan2 (deltaX, -deltaY) * Mathf.Rad2Deg;
		a.transform.eulerAngles = new Vector3 (0, 0, angle + delta);
	}

	public void TakeDamage()
	{
		health -= 1;
	}

	public void Kill()
	{
		health = 0;
	}

	void OnTriggerEnter2D(Collider2D  col)
	{
		if(col.gameObject.CompareTag("TAG_1"))
		{
			gameObject.SetActive(false);
		}
	}
}
