﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SplashInfo_20 : MonoBehaviour {

	private SpriteRenderer spriteRend;
	public float alpthSpeed = 0.5f;
	private float alpth = 1;

	void Start () {

		spriteRend = GetComponent<SpriteRenderer> ();
		DisplaySplath ();
	}


	public void DisplaySplath()
	{
		StartCoroutine (UpdateSplath ());
	}

	IEnumerator UpdateSplath()
	{
		alpth = 1;

		while(alpth > 0)
		{
			alpth -= Time.deltaTime * alpthSpeed;
			
			spriteRend.color = new Color (spriteRend.color.r, spriteRend.color.g, spriteRend.color.b, alpth);
			if (alpth <= 0)
				Destroy (gameObject);

			yield return null;
		}

	}
}
