using System.Collections;
using UnityEngine;
using UnityEngine.UI;








[System.Serializable]
public struct GameTimer
{
  
	public float min;
	public float max;
	
	[HideInInspector]public float timeLeftSpawn;
	
	void SetupTime()
	{
		ResetTime();
	}
	
	public void StartTime()
	{
		timeLeftSpawn -= Time.deltaTime;
	}
	
	public bool IsCompleteTime()
	{
		return timeLeftSpawn <= 0;
	}
	
	public void ResetTime()
	{
		timeLeftSpawn = GetRadnimValue();
	}
	
	public float GetRadnimValue()
	{
		return Random.Range(min, max);
	}
}



public class GameManager_20 : MonoBehaviour {

   public  int touched = 0;
    public static GameManager_20 instance;

    public AudioSource SFX;
    public AudioClip [] SFXclips;
   
  
    public int NoOfCuts = 0;
    public float ComboTime=0.6f;

    public Camera cam;

    public Bettr_Encryption.Encrypt BombLives;
    public string Bomb_Lives;
    public Text Lives;

    public bool gameOver = false;
    public bool effectCamera = false;

    //public float timer;
    //private float startTimer;

    public GameObject uiEndGame;

    public Text HitText;
    public int BossHits;


   
    [Header("UI Element")]
    public Text textScore;

    public Text Score;
    
    public Image imageScore;
    public Text textTimer;

   

    public Bettr_Encryption.Encrypt score;

    public string Score_Encrypt;

    public GameObject Combo3,Combo4,Combo5;
   
    
    void Awake()
    {
        if (instance != null)
            Destroy(gameObject);
        instance = this;



        
    }

    void Start()
    {
        Physics2D.gravity = new Vector2(0, -9.81f);
        Application.targetFrameRate = 60;



        score = new Bettr_Encryption.Encrypt(0);
        Score_Encrypt = "0";
        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);


        BombLives = new Bettr_Encryption.Encrypt(3);
        Bomb_Lives = "0";
        Bomb_Lives = XOREncryption.encryptDecrypt(Bomb_Lives);
        uiEndGame.SetActive (false);
        //startTimer = timer;
        //isTimer = true;
        StartCoroutine(CheckBonus(NoOfCuts));
    }

    public void ScoreInfo(Color c)
    {
        if (Score_Encrypt != string.Empty)
        {

            score += new Bettr_Encryption.Encrypt(1);
            Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
            Score_Encrypt = (int.Parse(Score_Encrypt) + 1).ToString();
            Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
        }
        textScore.color = c;
       
       
        HitText.color = c;

    }
    

    void Update()
    {

        HitText.text = BossHits + "  HITS ";

        Score.text =score.ToString();
        Score.color = textScore.color;










        

        Lives.text =  BombLives.ToString();

        if (int.Parse(BombLives.ToString()) <= 0)
        {
           
           
            Lives.color = Color.red;
            gameOver = true;
        
           

        }

      

       








            if (gameOver)
		{
			uiEndGame.SetActive (true);

	
			cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, 5, Time.deltaTime * 15);
           
           
         
            //	StartCoroutine(ChangeMouse());

            return;
		}else{
	//		textHighScore.text = "Last Score: " + scoreManager.score;
		}

		EffectCamera ();

		/*if(isTimer)
		{
			if(timer > 0)
			{
				timer -= Time.deltaTime;
				textTimer.text = "Timer: " + timer.ToString("0.0");
			}
		}



		textTimer.color = Color.Lerp (Color.red, Color.green ,timer / startTimer);*/
	}

	/*public IEnumerator FreezeTime()
	{
		//isTimer = false;
		yield return new WaitForSeconds (3);
		//isTimer = true;
	}

	public IEnumerator ChangeMouse()
	{
		yield return new WaitForSeconds (1);

		cam.gameObject.GetComponent<MouseController> ().enabled = false;
	}*/

	public void EffectCamera()
	{
        if (effectCamera)
        {
            cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, 3, Time.deltaTime * 15);
           
        }
        else
        {
      

            cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, 5, Time.deltaTime * 15);
        }
	}

    /*public void IncreaseTime()
	{
		timer += Mathf.RoundToInt (Random.Range (2, 5));
	}*/



    IEnumerator CheckBonus(int cuts)
    {
        yield return new WaitForSeconds(0.0001f);
        
        if(cuts > 0)
        {
            ComboTime -= Time.deltaTime;
            

            if (ComboTime < 0)
            {

                switch (cuts)
                {
                   

                    case 3:
                        
                        score += new Bettr_Encryption.Encrypt(8);
                        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
                        Score_Encrypt = (int.Parse(Score_Encrypt) + 8).ToString();
                        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
                        ComboTime = 0.6f;
                        NoOfCuts = 0;
                        Combo3.gameObject.SetActive(true);
                        SFX.PlayOneShot(SFXclips[0]);
                       
                        if(Combo3.activeSelf)
                        Combo3.GetComponent<Animation>().Play();

                        break;

                    case 4:
                        
                        score += new Bettr_Encryption.Encrypt(15);
                        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
                        Score_Encrypt = (int.Parse(Score_Encrypt) + 15).ToString();
                        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
                        ComboTime = 0.6f;
                        NoOfCuts = 0;
                        Combo4.gameObject.SetActive(true);
                        Combo3.gameObject.SetActive(false);
                        SFX.PlayOneShot(SFXclips[0]);
                        if (Combo4.activeSelf)
                            Combo4.GetComponent<Animation>().Play();

                        break;

                    case 5:
                      
                        score += new Bettr_Encryption.Encrypt(24);
                        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
                        Score_Encrypt = (int.Parse(Score_Encrypt) +24 ).ToString();
                        Score_Encrypt = XOREncryption.encryptDecrypt(Score_Encrypt);
                        ComboTime = 0.6f;
                        NoOfCuts = 0;
                        Combo5.gameObject.SetActive(true);
                        Combo4.gameObject.SetActive(false);
                        Combo3.gameObject.SetActive(false);
                        SFX.PlayOneShot(SFXclips[0]);
                        if (Combo5.activeSelf)
                            Combo5.GetComponent<Animation>().Play();

                        break;

                    default:
                        NoOfCuts = 0;
                        ComboTime = 0.6f;
                        Combo5.gameObject.SetActive(false);
                        Combo4.gameObject.SetActive(false);
                        Combo3.gameObject.SetActive(false);
                       


                        break;


                }

            }
        }
        StartCoroutine(CheckBonus(NoOfCuts));
    }
    

  void GameOverOntimer()
    {
        gameOver = true;

        if (gameOver)
            uiEndGame.SetActive(true);


    }

    






    public void KillAllFruit()
	{
		FruitInformation_20[] fruits = FindObjectsOfType<FruitInformation_20> ();
		if(fruits.Length > 0)
		{
			for (int i = 0; i < fruits.Length; i++) {
				if(!fruits[i].gameObject.GetComponent<FruitBoss_20>())
				{
					fruits[i].TakeDamage();
				    score +=new Bettr_Encryption.Encrypt(1);
				}
			}
		}
	}
}
