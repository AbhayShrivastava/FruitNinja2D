﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyPiece_20 : MonoBehaviour {

	void Start () {

		Destroy (gameObject, 3);
	}
	
	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.gameObject.CompareTag ("Dead"))
			gameObject.SetActive (false);
	}
}
