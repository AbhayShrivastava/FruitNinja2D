﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;




public class BombInformation_20 : MonoBehaviour {

	private ImageEffect_20 imageBomb;
    private Animation anim;
    private Rigidbody2D RB;
    float delay=1f;
   
    bool Bombhit = false;

	void Awake () {
        RB = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animation>();
		imageBomb = GameObject.Find("Image Bomb Effect").GetComponent<ImageEffect_20>();
	}
    private void Update()
    {
     
        if (Bombhit==true && int.Parse(GameManager_20.instance.BombLives.ToString())>1)
        {

           if (int.Parse(GameManager_20.instance.BombLives.ToString())>0)
            GameManager_20.instance.BombLives = new Bettr_Encryption.Encrypt(int.Parse(GameManager_20.instance.BombLives.ToString()) - 1);
            GameManager_20.instance.Bomb_Lives = XOREncryption.encryptDecrypt(GameManager_20.instance.Bomb_Lives);
            GameManager_20.instance.Bomb_Lives = (int.Parse(GameManager_20.instance.Bomb_Lives) - 1).ToString();
            GameManager_20.instance.Bomb_Lives = XOREncryption.encryptDecrypt(GameManager_20.instance.Bomb_Lives);
            DestrotAllFruit();
            gameObject.SetActive(false);
            imageBomb.gameObject.SetActive(true);
            imageBomb.ApplyEffect();
          
            Bombhit = false;

            
        }
         if (Bombhit == true &&int.Parse(GameManager_20.instance.BombLives.ToString())<2)
        {
            delay -= Time.deltaTime;
            if (int.Parse(GameManager_20.instance.BombLives.ToString()) > 0)
                GameManager_20.instance.BombLives = new Bettr_Encryption.Encrypt(int.Parse(GameManager_20.instance.BombLives.ToString()) - 1);
            GameManager_20.instance.Bomb_Lives = XOREncryption.encryptDecrypt(GameManager_20.instance.Bomb_Lives);
            GameManager_20.instance.Bomb_Lives = (int.Parse(GameManager_20.instance.Bomb_Lives) - 1).ToString();
            GameManager_20.instance.Bomb_Lives = XOREncryption.encryptDecrypt(GameManager_20.instance.Bomb_Lives);
            DestrotAllFruit();
            
            RB.bodyType = RigidbodyType2D.Static;
            anim.Play();
        }
         if (delay<0)
        {
            imageBomb.gameObject.SetActive(true);
            imageBomb.ApplyEffect();
            gameObject.SetActive(false);

        }
    }

    public void ApplyBombEffect()
	{
       


        
        Bombhit = true;
               
           
        
	}

	void DestrotAllFruit()
	{
		FruitInformation_20[] fruits = FindObjectsOfType<FruitInformation_20> ();
		if(fruits.Length > 0)
		{
			for (int i = 0; i < fruits.Length; i++) {
				if(!fruits[i].gameObject.GetComponent<FruitBoss_20>())
				{
					fruits[i].Kill();
				}
			}
		}
	}
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("TAG_1"))
            Destroy(gameObject);
    }

}
