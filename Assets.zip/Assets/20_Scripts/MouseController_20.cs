using System.Collections;
using UnityEngine;

public class MouseController_20 : MonoBehaviour {

	public static MouseController_20 Instance{get; set;}
    public GameObject blade;
    private Animation camAnim;
  private TrailRenderer Trail;

   
    

	private float speedX;
	private float speedY;

	void Awake()
	{
		Instance = this;

        Input.multiTouchEnabled = false;

        Trail = blade.GetComponent<TrailRenderer>();

	}

	void Start()
	{
		GameManager_20.instance.ScoreInfo (Color.white);
        camAnim = GameManager_20.instance.cam.GetComponent<Animation>();

	}

	public Vector2 GetMousePosition()
	{
     
		return Camera.main.ScreenToWorldPoint (Input.mousePosition);
	}

	void Update () {


       if(Input.touchCount>0)
       
            if (Input.GetTouch(0).phase == TouchPhase.Moved)
            {

                Trail.enabled = false;
                Vector2 mousePos = GetMousePosition();

                speedX = Input.GetAxisRaw("Mouse X");
                speedY = Input.GetAxisRaw("Mouse Y");

                Vector2 speedMouse = new Vector2(speedX, speedY);

                if (speedMouse.magnitude > 0.5f)
                {
                    Trail.enabled = true;
                    UpdateTrailPosition(mousePos);
                    CutFruit(mousePos);
                }
                else
                    Trail.enabled = false;



            }
       else if (Input.GetTouch(0).phase==TouchPhase.Ended)
            {
                Trail.enabled = false;
            }
        
         
	}

	void CutFruit(Vector2 pos)
	{
       
        RaycastHit2D [] Hit = Physics2D.BoxCastAll(pos, Vector2.one,90,Vector2.down,0.2f);


        RaycastHit2D hit2= Physics2D.BoxCast(pos, Vector2.one, 90, Vector2.down, 0.2f);

        if(hit2.collider!=null)
        if (hit2.collider.gameObject.GetComponent<FruitBoss_20>())
        {
            GameManager_20.instance.BossHits++;
            GameManager_20.instance.HitText.gameObject.SetActive(true);
            GetFruit(hit2.transform);

            Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, new Vector2(speedX, speedY), Time.smoothDeltaTime * 2f);


        }

        foreach (RaycastHit2D hit in Hit)
        {
            if (hit.collider != null)
            {
                if (hit.collider.gameObject.GetComponent<FruitInformation_20>())
                {
                    GetFruit(hit.transform);
                  

                }

              



                //BOMB CONDITION

                if (hit.collider.gameObject.GetComponent<BombInformation_20>())
                {
                    BombInformation_20 bomb = hit.collider.gameObject.GetComponent<BombInformation_20>();

                    bomb.ApplyBombEffect();
                    if (!camAnim.isPlaying)
                        camAnim.Play();
                    AudioMaster_20.Instance.audioCut.clip = GameManager_20.instance.SFXclips[1];
                    AudioMaster_20.Instance.ApplyAudioCut();


                }

            }
        }

		//Debug.DrawRay (pos, Vector2.up * 0.1f, Color.green);
	}

    void GetFruit(Transform t)
    {
        FruitInformation_20 fruit = t.gameObject.GetComponent<FruitInformation_20>();
        fruit.TakeDamage();
        fruit.GetEffect();

        GameManager_20.instance.ScoreInfo(fruit.colorFruit);
        GameManager_20.instance.imageScore.sprite = fruit.GetComponent<SpriteRenderer>().sprite;
        if (!AudioMaster_20.Instance.audioCut.isPlaying)
        {
            AudioMaster_20.Instance.audioCut.clip = GameManager_20.instance.SFXclips[3];
            AudioMaster_20.Instance.ApplyAudioCut();
        }

    }
	
	void UpdateTrailPosition(Vector2 pos)
	{
       
	   blade.transform.position = new Vector3(pos.x, pos.y, 0);
       
	}

  

  
    
}
