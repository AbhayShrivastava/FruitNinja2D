﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitManager_20 : MonoBehaviour {

	[System.Serializable]
	public struct Fruit
	{
		public string name;
		public GameObject fruitPrefab;
		public int maxPool;

		public ObjectPooling_20 fruitPool;

		public void Init()
		{
			fruitPool = new ObjectPooling_20(fruitPrefab, maxPool);
		}
	}

	[System.Serializable]
	public struct SuperFruit
	{
		public Transform fruit;
		public bool isAvailable;
		public GameTimer timer;
	}

	public float maxSpeed = 15;
	public float minSpeed = 13;
	public float speedRotate = 1;


	

	[Space(20)]
	[Header("Fruits Timer")]
	public GameTimer numberFruitWave;
	public GameTimer normalFruitTimer;
	public bool useBomb;
	public GameTimer bombTimer;

	[Space(20)]
	[Header("Prefabs Object")]
	public Transform bomb;
	public Transform[] bossFruits;
	public Fruit[] normalFruits;
	public Transform[] points;

   

	public bool isShootBoss = false;

	void Awake()
	{
		for (int i = 0; i < normalFruits.Length; i++) {
			
			normalFruits[i].Init();
		}
	}

	void Start()
	{
		useBomb = true;

		
	}

	void Update () {
       
		if (GameManager_20.instance.gameOver||isShootBoss) // Game Over
			return;
		
		// --------------- Normal Fruits ----------------


			normalFruitTimer.StartTime();

       //After big boss game should continue
        if (!isShootBoss)
        {
           
            if (normalFruitTimer.IsCompleteTime())
            {
                useBomb = true;
                ShootNormalFruit();
                normalFruitTimer.ResetTime();
            }
        }

       //Wave genertor condition

			if ((int.Parse(GameManager_20.instance.score.ToString()) % 47) == 0) {

				ShootFruitWave ();
				ShootBomb();
				
		   GameManager_20.instance.score += new Bettr_Encryption.Encrypt(1);
           GameManager_20.instance.Score_Encrypt = XOREncryption.encryptDecrypt(GameManager_20.instance.Score_Encrypt);
           GameManager_20.instance.Score_Encrypt = (int.Parse(GameManager_20.instance.Score_Encrypt) + 1).ToString();
           GameManager_20.instance.Score_Encrypt = XOREncryption.encryptDecrypt(GameManager_20.instance.Score_Encrypt);

        } else {

				if (normalFruitTimer.IsCompleteTime()) {

					ShootNormalFruit ();
					normalFruitTimer.ResetTime();
				}
			}

		

		// --------------- Bomb ----------------

		bombTimer.StartTime();
		if (bombTimer.IsCompleteTime()) {
			if (useBomb) {
				ShootBomb ();
				bombTimer.ResetTime();
			}
		}

		
		
		// --------------- Boss Fruit ----------------
		
		if ((int.Parse(GameManager_20.instance.score.ToString()) % 97)==0&&GameManager_20.instance.gameOver==false) {
			int randomBoss = Random.Range (0, bossFruits.Length);
            
			SingleShoot (bossFruits [randomBoss].transform, transform, Quaternion.identity, 10);
			isShootBoss = true;
            useBomb = false;
		}
	}
    









	void ShootBomb()
	{
		float randomSpeed = Random.Range (minSpeed, maxSpeed);
		int randomPoint = Random.Range (0, points.Length);
		
		SingleShoot(bomb,points [randomPoint], points [randomPoint].rotation, randomSpeed);
	}

	void ShootSuperFruit(Transform t)
	{
		float randomSpeed = Random.Range (minSpeed, maxSpeed);
		int randomPoint = Random.Range (0, points.Length);

		SingleShoot(t,points [randomPoint], points [randomPoint].rotation, randomSpeed);
	}
	
	void ShootFruitWave()
	{
		int randomWava = (int)numberFruitWave.GetRadnimValue();
		
		for (int i = 0; i < randomWava; i++) {
			ShootNormalFruit();
		}
	}

	void SingleShoot(Transform t,Transform pos, Quaternion rot, float speed)
	{
		GameObject obj = Instantiate (t.gameObject, pos.position, rot) as GameObject;
		obj.GetComponent<Rigidbody2D> ().velocity = pos.up * speed;
		obj.GetComponent<Rigidbody2D> ().AddTorque (50 * speedRotate);
	}

	void ShootNormalFruit()
	{
		int randomPoint = Random.Range (0, points.Length);
		int randomFruits = Random.Range (0, normalFruits.Length);

		float randomSpeed = Random.Range (minSpeed, maxSpeed);
		float randomRotate = Mathf.RoundToInt(Random.Range (-70, 70));

		GameObject obj = normalFruits[randomFruits].fruitPool.GetObject();
		obj.transform.position = points[randomPoint].position;
		obj.GetComponent<Rigidbody2D> ().velocity = points [randomPoint].up * randomSpeed;
		obj.GetComponent<Rigidbody2D> ().AddTorque (randomRotate * speedRotate);
	}

    
}
