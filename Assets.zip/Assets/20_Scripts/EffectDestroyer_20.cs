﻿using UnityEngine;
using System.Collections;

public class EffectDestroyer_20 : MonoBehaviour {

	void Start () {
	
		Destroy(gameObject, 5);
	}
}
